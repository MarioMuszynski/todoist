# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['todoist']

package_data = \
{'': ['*'], 'todoist': ['build/create_gui/*', 'dist/*']}

install_requires = \
['PyAutoGUI>=0.9.53,<0.10.0', 'PyQt5>=5.15.6,<6.0.0', 'pandas>=1.4.2,<2.0.0']

setup_kwargs = {
    'name': 'todoist',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
